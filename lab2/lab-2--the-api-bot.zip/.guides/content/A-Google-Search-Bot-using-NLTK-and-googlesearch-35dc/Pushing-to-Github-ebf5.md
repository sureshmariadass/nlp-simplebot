## Pushing to GitHub

Before continuing, you must push your work to GitHub. 
In the terminal:

* Commit your changes:

```bash 
git add .
git commit -m "Finished The API Bot"
```

* Push to GitHub:

```bash
git push
```