---

### Learners will be able to...
* Describe and implement tokenization and lemmatization on a corpus
* Describe and implement TFIDF and Cosine Similarity
* Create a chatbot in Python that uses an API to fetch data, with a tkinter GUI



|||info
## Make Sure to Know
Intermediate Python.

## Limitations
In this assignment, we only work with the tkinter and NLTK libraries.
|||

---